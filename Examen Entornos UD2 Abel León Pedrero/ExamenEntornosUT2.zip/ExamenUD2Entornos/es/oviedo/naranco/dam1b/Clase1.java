package es.oviedo.naranco.dam1b;

public class Clase1 {

	public static void main(String[] args) {
		int suma=0;
		for(int i=0; i<1500;i++) {
			suma=suma+(i*2);
			System.out.println(suma);
		}

	}

}
